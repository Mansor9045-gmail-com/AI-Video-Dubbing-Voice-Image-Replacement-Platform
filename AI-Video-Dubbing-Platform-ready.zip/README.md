# AI Video Dubbing Platform

منصة أصلية لدبلجة الفيديو بالذكاء الاصطناعي، مبنية على سير العمل الظاهر في الصور المرفقة.

المسار:
رفع الفيديو -> Whisper -> التوقيت -> SRT -> ترجمة اختيارية -> TTS -> مزامنة مدة الصوت -> FFmpeg -> MP4

## تشغيل محلي
```bash
python -m venv .venv
# Windows
.venv\Scripts\activate
# Linux/macOS
source .venv/bin/activate

pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

ثم افتح http://localhost:8000

## Docker
```bash
docker compose up --build
```

## المتطلبات
- Python 3.11
- FFmpeg
- GPU NVIDIA اختياري لتسريع Whisper
- Ollama اختياري للترجمة المحلية

## API
POST /api/jobs/dub
GET /api/jobs/{job_id}
GET /api/jobs/{job_id}/srt
GET /api/jobs/{job_id}/download

ملاحظة: استنساخ صوت شخص حقيقي يجب أن يكون بموافقته.
