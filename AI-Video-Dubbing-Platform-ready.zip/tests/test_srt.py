from app.pipeline import write_srt
def test_srt(tmp_path):
    p=tmp_path/"x.srt"
    write_srt([{"start":0,"end":1.5,"text":"Hello"}],p)
    assert "Hello" in p.read_text(encoding="utf-8")
    assert "-->" in p.read_text(encoding="utf-8")
