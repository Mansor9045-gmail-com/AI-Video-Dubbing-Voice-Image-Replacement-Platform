from pathlib import Path
import os, subprocess, asyncio, datetime
import srt, httpx, edge_tts
from faster_whisper import WhisperModel

def cmd(*args):
    p=subprocess.run(args,capture_output=True,text=True)
    if p.returncode: raise RuntimeError(p.stderr[-4000:])
    return p

def extract_audio(video,wav):
    cmd("ffmpeg","-y","-i",str(video),"-vn","-ac","1","-ar","16000",str(wav))

def write_srt(segments,path):
    subs=[]
    for i,x in enumerate(segments,1):
        subs.append(srt.Subtitle(i,datetime.timedelta(seconds=x["start"]),
                                 datetime.timedelta(seconds=x["end"]),x["text"]))
    path.write_text(srt.compose(subs),encoding="utf-8")

def transcribe(wav):
    model=WhisperModel(os.getenv("WHISPER_MODEL","small"),
                       device=os.getenv("WHISPER_DEVICE","cpu"),
                       compute_type=os.getenv("WHISPER_COMPUTE_TYPE","int8"))
    segs,info=model.transcribe(str(wav),vad_filter=True)
    return [{"start":float(x.start),"end":float(x.end),"text":x.text.strip()} for x in segs],info.language

async def translate(text,source,target):
    if os.getenv("TRANSLATION_BACKEND","none").lower()!="ollama": return text
    url=os.getenv("OLLAMA_URL","http://localhost:11434")
    model=os.getenv("OLLAMA_MODEL","qwen2.5:7b")
    prompt=f"Translate from {source} to {target}. Return only the translation. Preserve meaning and names.\n{text}"
    async with httpx.AsyncClient(timeout=120) as c:
        r=await c.post(f"{url}/api/generate",json={"model":model,"prompt":prompt,"stream":False})
        r.raise_for_status()
        return r.json()["response"].strip()

async def tts(text,voice,out):
    await edge_tts.Communicate(text,voice).save(str(out))

def fit_duration(src,dst,target):
    p=cmd("ffprobe","-v","error","-show_entries","format=duration","-of","default=nw=1:nk=1",str(src))
    dur=float(p.stdout.strip())
    ratio=dur/max(target,0.05)
    filters=[]
    while ratio>2: filters.append("atempo=2"); ratio/=2
    while ratio<0.5: filters.append("atempo=0.5"); ratio/=0.5
    filters.append(f"atempo={ratio:.6f}")
    cmd("ffmpeg","-y","-i",str(src),"-filter:a",",".join(filters),"-ar","48000","-ac","2",str(dst))

def mix(clips,out,duration):
    args=[]; fs=[]; labels=[]
    for i,(start,p) in enumerate(clips):
        args += ["-i",str(p)]
        ms=int(start*1000); label=f"a{i}"; labels.append(f"[{label}]")
        fs.append(f"[{i}:a]adelay={ms}|{ms}[{label}]")
    fs.append("".join(labels)+f"amix=inputs={len(clips)}:duration=longest:dropout_transition=0[out]")
    cmd("ffmpeg","-y",*args,"-filter_complex",";".join(fs),"-map","[out]","-t",str(duration),"-ar","48000","-ac","2",str(out))

async def run_dubbing(input_path,job_dir,output_dir,target_language,voice,do_translate):
    job_dir.mkdir(parents=True,exist_ok=True); output_dir.mkdir(parents=True,exist_ok=True)
    wav=job_dir/"source.wav"; extract_audio(input_path,wav)
    segments,source=await asyncio.to_thread(transcribe,wav)
    if do_translate:
        for x in segments: x["text"]=await translate(x["text"],source,target_language)
    srt_path=job_dir/"translated.srt"; write_srt(segments,srt_path)
    clips=[]
    for i,x in enumerate(segments):
        raw=job_dir/f"{i:05d}.mp3"; fitted=job_dir/f"{i:05d}.wav"
        await tts(x["text"],voice,raw)
        await asyncio.to_thread(fit_duration,raw,fitted,x["end"]-x["start"])
        clips.append((x["start"],fitted))
    duration=max((x["end"] for x in segments),default=0)
    dubbed=job_dir/"dubbed.wav"; mix(clips,dubbed,duration)
    out=output_dir/f"{job_dir.name}-dubbed.mp4"
    cmd("ffmpeg","-y","-i",str(input_path),"-i",str(dubbed),"-map","0:v:0","-map","1:a:0","-c:v","copy","-c:a","aac","-shortest",str(out))
    return {"srt":srt_path,"video":out}
