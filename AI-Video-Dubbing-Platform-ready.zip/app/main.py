from pathlib import Path
from uuid import uuid4
import asyncio
from fastapi import FastAPI, File, Form, UploadFile, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from .pipeline import run_dubbing

BASE=Path("data")
UPLOADS=BASE/"uploads"; WORK=BASE/"work"; OUTPUT=BASE/"output"
for p in (UPLOADS,WORK,OUTPUT): p.mkdir(parents=True,exist_ok=True)

app=FastAPI(title="AI Video Dubbing Platform",version="0.1.0")
app.mount("/static",StaticFiles(directory="web"),name="static")
jobs={}

@app.get("/")
async def home():
    return FileResponse("web/index.html")

@app.post("/api/jobs/dub")
async def create_job(video:UploadFile=File(...),target_language:str=Form("en"),
                     voice:str=Form("en-US-AriaNeural"),translation:bool=Form(True)):
    job_id=uuid4().hex
    suffix=Path(video.filename or "video.mp4").suffix or ".mp4"
    path=UPLOADS/f"{job_id}{suffix}"
    with path.open("wb") as f:
        while chunk:=await video.read(1024*1024):
            f.write(chunk)
    jobs[job_id]={"status":"queued","progress":0}
    asyncio.create_task(_run(job_id,path,target_language,voice,translation))
    return {"job_id":job_id,"status":"queued"}

async def _run(job_id,path,target_language,voice,translation):
    try:
        jobs[job_id].update(status="processing",progress=10)
        result=await run_dubbing(path,WORK/job_id,OUTPUT,target_language,voice,translation)
        jobs[job_id].update(status="completed",progress=100,srt=str(result["srt"]),video=str(result["video"]))
    except Exception as e:
        jobs[job_id].update(status="error",error=str(e))

@app.get("/api/jobs/{job_id}")
async def status(job_id:str):
    if job_id not in jobs: raise HTTPException(404,"Job not found")
    return jobs[job_id]

@app.get("/api/jobs/{job_id}/srt")
async def get_srt(job_id:str):
    j=jobs.get(job_id)
    if not j or j.get("status")!="completed": raise HTTPException(404,"SRT not ready")
    return FileResponse(j["srt"],media_type="application/x-subrip",filename=f"{job_id}.srt")

@app.get("/api/jobs/{job_id}/download")
async def download(job_id:str):
    j=jobs.get(job_id)
    if not j or j.get("status")!="completed": raise HTTPException(404,"Video not ready")
    return FileResponse(j["video"],media_type="video/mp4",filename=f"{job_id}-dubbed.mp4")
